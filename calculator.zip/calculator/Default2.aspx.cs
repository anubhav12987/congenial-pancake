﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    static double firstNumber, secondNumber, result;
    static char operation;
    string Res = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "0" && TextBox1.Text != null)
        {
            TextBox1.Text = "1";
        }
        else
        {
            TextBox1.Text = TextBox1.Text + "1";
        }
    }


    protected void Button2_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "0" && TextBox1.Text != null)
        {
            TextBox1.Text = "2";
        }
        else
        {
            TextBox1.Text = TextBox1.Text + "2";
        }
    }


    protected void Button3_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "0" && TextBox1.Text != null)
        {
            TextBox1.Text = "3";
        }
        else
        {
            TextBox1.Text = TextBox1.Text + "3";
        }
    }


    protected void Button4_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "0" && TextBox1.Text != null)
        {
            TextBox1.Text = "4";
        }
        else
        {
            TextBox1.Text = TextBox1.Text + "4";
        }
    }


    protected void ButtonAdd_Click(object sender, EventArgs e)
    {
        TextBox1.Text = TextBox1.Text + "+";
        operation = '+';
    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "0" && TextBox1.Text != null)
        {
            TextBox1.Text = "5";
        }
        else
        {
            TextBox1.Text = TextBox1.Text + "5";
        }
    }

    protected void Button6_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "0" && TextBox1.Text != null)
        {
            TextBox1.Text = "6";
        }
        else
        {
            TextBox1.Text = TextBox1.Text + "6";
        }
    }


    protected void ButtonSub_Click(object sender, EventArgs e)
    {
        TextBox1.Text = TextBox1.Text + "-";
        operation = '-';
    }

    protected void Button7_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "0" && TextBox1.Text != null)
        {
            TextBox1.Text = "7";
        }
        else
        {
            TextBox1.Text = TextBox1.Text + "7";
        }
    }

    protected void Button8_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "0" && TextBox1.Text != null)
        {
            TextBox1.Text = "8";
        }
        else
        {
            TextBox1.Text = TextBox1.Text + "8";
        }
    }


    protected void Button9_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "0" && TextBox1.Text != null)
        {
            TextBox1.Text = "9";
        }
        else
        {
            TextBox1.Text = TextBox1.Text + "9";
        }
    }

    protected void ButtonMul_Click(object sender, EventArgs e)
    {
        TextBox1.Text = TextBox1.Text + "*";
        operation = '*';
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }


    protected void ButtonEqual_Click(object sender, EventArgs e)
    {
        calc(TextBox1.Text);
        TextBox1.Text = TextBox1.Text +"="+ Res;
        if ( TextBox1.Text.Contains("=")==true)
        {
            if (TextBox1.Text == " " && TextBox1.Text != null)
            {
                TextBox1.Text = " ";
            }
            else
            {
                TextBox1.Text = TextBox1.Text + " ";
            }
        }
     

    }

    public void calc(string Value)
    {
        
        double result;
        if (operation == '+')
        {
            string[] divide = Value.Split('+');
            firstNumber = Convert.ToDouble(divide[0]);
            secondNumber = Convert.ToDouble(divide[1]);
            result = firstNumber + secondNumber;
            Res = Convert.ToString(result);
        }
        else if (operation == '-')
        {
            string[] divide = Value.Split('-');
            firstNumber = Convert.ToDouble(divide[0]);
            secondNumber = Convert.ToDouble(divide[1]);
            result = firstNumber - secondNumber;
            Res = Convert.ToString(result);
        }
        else if (operation == 'x')
        {
            string[] divide = Value.Split('x');
            firstNumber = Convert.ToDouble(divide[0]);
            secondNumber = Convert.ToDouble(divide[1]);
            result = firstNumber * secondNumber;
            Res = Convert.ToString(result);
        }
        else if (operation == '/')
        {
            string[] divide = Value.Split('/');
            firstNumber = Convert.ToDouble(divide[0]);
            secondNumber = Convert.ToDouble(divide[1]);
            result = firstNumber / secondNumber;
            Res = Convert.ToString(result);
        }
       
    }









    protected void ButtonDiv_Click(object sender, EventArgs e)
    {
        TextBox1.Text = TextBox1.Text + "/";
        operation = '/';
    }

    protected void Button0_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "0" && TextBox1.Text != null)
        {
            TextBox1.Text = "0";
        }
        else
        {
            TextBox1.Text = TextBox1.Text + "0";
        }
    }

    protected void ButtonDot_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "0" && TextBox1.Text != null)
        {
            TextBox1.Text = ".";
        }
        else
        {
            TextBox1.Text = TextBox1.Text + ".";
        }
    }




    protected void Button10_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";

    }
}


